// background.js

chrome.action.onClicked.addListener(function() {
    console.log('action clicked');
  });